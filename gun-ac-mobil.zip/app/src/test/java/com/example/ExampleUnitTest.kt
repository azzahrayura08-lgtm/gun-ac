package com.example

import com.example.data.config.WhatsAppConfig
import com.example.data.model.BookingFormState
import com.example.data.model.ChatPayload
import com.example.data.model.MenuId
import com.example.data.repository.ChatbotRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ExampleUnitTest {

    private lateinit var repository: ChatbotRepository

    @Before
    fun setUp() {
        repository = ChatbotRepository()
    }

    @Test
    fun testInitialGreetingMessage() {
        val greeting = repository.getInitialGreeting()
        assertTrue(greeting.text.contains("Selamat datang di GUN AC MOBIL. Ada yang bisa kami bantu?"))
        assertTrue(greeting.showMainMenu)
        assertEquals(5, greeting.quickReplies.size)
    }

    @Test
    fun testMainMenuOptionsList() {
        val options = repository.mainMenuOptions
        assertEquals(5, options.size)
        assertEquals("Konsultasi kerusakan AC mobil", options[0].title)
        assertEquals("Booking jadwal servis", options[1].title)
        assertEquals("Informasi layanan bengkel", options[2].title)
        assertEquals("Lokasi dan jam operasional", options[3].title)
        assertEquals("Hubungi admin", options[4].title)
    }

    @Test
    fun testCategory1_AcTidakDingin() {
        val res = repository.processUserQuery("AC mobil saya tidak dingin sama sekali")
        assertTrue(res.text.contains("tidak dingin", ignoreCase = true) || res.text.contains("keluar angin", ignoreCase = true))
        assertTrue(res.text.contains("Catatan Teknisi") || res.text.contains("teknisi", ignoreCase = true))
        assertTrue(res.showWhatsAppButton)
    }

    @Test
    fun testCategory2_AcHanyaKeluarAngin() {
        val res = repository.processUserQuery("AC hanya keluar angin saja seperti kipas")
        assertTrue(res.text.contains("keluar angin", ignoreCase = true))
        assertTrue(res.text.contains("Catatan Teknisi") || res.text.contains("teknisi", ignoreCase = true))
        assertTrue(res.showWhatsAppButton)
    }

    @Test
    fun testCategory3_AcBerbauTidakSedap() {
        val res = repository.processUserQuery("AC berbau tidak sedap dan apek")
        assertTrue(res.text.contains("berbau tidak sedap", ignoreCase = true) || res.text.contains("bau", ignoreCase = true))
        assertTrue(res.text.contains("Catatan Teknisi") || res.text.contains("teknisi", ignoreCase = true))
        assertTrue(res.showWhatsAppButton)
    }

    @Test
    fun testCategory4_AcBerbunyiBerisik() {
        val res = repository.processUserQuery("saat AC nyala timbul suara berbunyi berisik dan kasar")
        assertTrue(res.text.contains("berbunyi berisik", ignoreCase = true) || res.text.contains("bunyi", ignoreCase = true))
        assertTrue(res.text.contains("Catatan Teknisi") || res.text.contains("teknisi", ignoreCase = true))
        assertTrue(res.showWhatsAppButton)
    }

    @Test
    fun testCategory5_AcKadangDinginKadangPanas() {
        val res = repository.processUserQuery("AC kadang dingin kadang panas kalau lagi macet")
        assertTrue(res.text.contains("kadang dingin kadang panas", ignoreCase = true))
        assertTrue(res.text.contains("Catatan Teknisi") || res.text.contains("teknisi", ignoreCase = true))
        assertTrue(res.showWhatsAppButton)
    }

    @Test
    fun testCategory6_PerawatanAcMobil() {
        val res = repository.processUserQuery("bagaimana tips perawatan AC mobil yang baik?")
        assertTrue(res.text.contains("Perawatan Rutin AC Mobil", ignoreCase = true))
        assertTrue(res.showWhatsAppButton)
    }

    @Test
    fun testCategory7_BookingServis() {
        val res = repository.processUserQuery("saya ingin booking servis AC mobil")
        assertTrue(res.text.contains("booking jadwal", ignoreCase = true))
        assertTrue(res.quickReplies.any { it.payloadText == "FORM_BOOKING" })
        assertTrue(res.showWhatsAppButton)
    }

    @Test
    fun testCategory8_AlamatBengkel() {
        val res = repository.processUserQuery("di mana alamat bengkel GUN AC MOBIL?")
        assertTrue(res.text.contains("Jl. Letjen S. Parman, Pasar Sayur Pabuaran, Cirebon Timur."))
        assertTrue(res.payload is ChatPayload.LocationAndHours)
    }

    @Test
    fun testCategory9_JamOperasional() {
        val res = repository.processUserQuery("jam operasional buka bengkel hari apa saja?")
        assertTrue(res.text.contains("08:00 - 17:00 WIB"))
        assertTrue(res.payload is ChatPayload.LocationAndHours)
    }

    @Test
    fun testCategory10_JenisLayananBengkel() {
        val res = repository.processUserQuery("apa saja jenis layanan bengkel di sini?")
        assertTrue(res.payload is ChatPayload.ServiceInfo)
        val catalog = res.payload as ChatPayload.ServiceInfo
        assertTrue(catalog.highlights.isNotEmpty())
    }

    @Test
    fun testMenuSelection1_Diagnosis() {
        val response = repository.handleMenuSelection(MenuId.KONSULTASI_RUSAK)
        assertTrue(response.payload is ChatPayload.DiagnosisGuide)
        val diagnosis = response.payload as ChatPayload.DiagnosisGuide
        assertTrue(diagnosis.symptoms.isNotEmpty())
    }

    @Test
    fun testMenuSelection4_LocationAndHours() {
        val response = repository.handleMenuSelection(MenuId.LOKASI_OPERASIONAL)
        assertTrue(response.payload is ChatPayload.LocationAndHours)
        val loc = response.payload as ChatPayload.LocationAndHours
        assertTrue(loc.address.contains("Jl. Letjen S. Parman, Pasar Sayur Pabuaran, Cirebon Timur."))
        assertTrue(loc.mapsUrl.contains("query=GUN+AC+MOBIL+Jl+Letjen+S+Parman+Pasar+Sayur+Pabuaran+Cirebon+Timur"))
    }

    @Test
    fun testMenuSelection5_Admin() {
        val response = repository.handleMenuSelection(MenuId.HUBUNGI_ADMIN)
        assertTrue(response.showWhatsAppButton)
        assertTrue(response.payload is ChatPayload.AdminContact)
        val admin = response.payload as ChatPayload.AdminContact
        assertTrue(admin.address.contains("Jl. Letjen S. Parman, Pasar Sayur Pabuaran, Cirebon Timur."))
    }

    @Test
    fun testPriceQueryRedirectsToWhatsApp() {
        val priceResponse = repository.processUserQuery("Berapa estimasi biaya cuci ac?")
        assertTrue(priceResponse.text.contains("WhatsApp"))
        assertTrue(priceResponse.showWhatsAppButton)
    }

    @Test
    fun testCustomQuery_UnknownFallbackRedirectsToAdmin() {
        val response = repository.processUserQuery("apakah menjual tiket konser musik?")
        assertTrue(response.text.contains("belum sepenuhnya memahami") || response.text.contains("belum dapat kami jawab"))
        assertTrue(response.text.contains("WhatsApp"))
        assertTrue(response.showWhatsAppButton)
    }

    @Test
    fun testOfficialContactDetails() {
        assertEquals("081324782858", WhatsAppConfig.OFFICIAL_PHONE_DISPLAY)
        assertEquals("6281324782858", WhatsAppConfig.OFFICIAL_PHONE_INTERNATIONAL)
        assertEquals("Jl. Letjen S. Parman, Pasar Sayur Pabuaran, Cirebon Timur.", WhatsAppConfig.WORKSHOP_ADDRESS)
        assertEquals(
            "https://www.google.com/maps/search/?api=1&query=GUN+AC+MOBIL+Jl+Letjen+S+Parman+Pasar+Sayur+Pabuaran+Cirebon+Timur",
            WhatsAppConfig.GOOGLE_MAPS_URL
        )
        assertEquals("Halo GUN AC MOBIL", WhatsAppConfig.DEFAULT_PREFILL_TEXT)
        assertEquals(
            "whatsapp://send?phone=6281324782858&text=Halo%20GUN%20AC%20MOBIL",
            WhatsAppConfig.OFFICIAL_DEEP_LINK
        )

        val deepLink = WhatsAppConfig.buildDeepLinkUrl()
        assertEquals(
            "whatsapp://send?phone=6281324782858&text=Halo%20GUN%20AC%20MOBIL",
            deepLink
        )

        val waMeUrl = WhatsAppConfig.buildWaMeUrl()
        assertEquals(
            "https://wa.me/6281324782858?text=Halo%20GUN%20AC%20MOBIL",
            waMeUrl
        )
    }

    @Test
    fun testBookingConfirmation() {
        val booking = BookingFormState(
            customerName = "Ahmad Hidayat",
            phoneNumber = "081324782858",
            carBrandModel = "Toyota Innova",
            carYear = "2021",
            servicePackage = "Flushing & Pengisian Freon R134a",
            selectedDate = "Besok",
            selectedTime = "10:00 WIB"
        )
        val response = repository.generateBookingConfirmation(booking)
        assertTrue(response.payload is ChatPayload.BookingSummary)
        val summary = response.payload as ChatPayload.BookingSummary
        assertTrue(summary.bookingCode.startsWith("GUN-"))
        assertEquals("Ahmad Hidayat", summary.customerName)
        assertTrue(response.text.contains(WhatsAppConfig.WORKSHOP_ADDRESS))
    }
}
