package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.config.WhatsAppConfig
import com.example.data.model.BookingFormState
import com.example.data.model.ChatMessage
import com.example.data.model.MenuId
import com.example.data.model.MenuOption
import com.example.data.model.QuickReply
import com.example.data.model.SenderType
import com.example.data.repository.ChatbotRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class WhatsAppDialogState(
    val phoneNumber: String,
    val messageText: String,
    val isPlaceholder: Boolean,
    val note: String,
    val waMeUrl: String
)

class GunAcViewModel(
    private val repository: ChatbotRepository = ChatbotRepository()
) : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isChatOpen = MutableStateFlow(false)
    val isChatOpen: StateFlow<Boolean> = _isChatOpen.asStateFlow()

    private val _isTyping = MutableStateFlow(false)
    val isTyping: StateFlow<Boolean> = _isTyping.asStateFlow()

    private val _inputMessage = MutableStateFlow("")
    val inputMessage: StateFlow<String> = _inputMessage.asStateFlow()

    private val _showBookingModal = MutableStateFlow(false)
    val showBookingModal: StateFlow<Boolean> = _showBookingModal.asStateFlow()

    private val _bookingState = MutableStateFlow(BookingFormState())
    val bookingState: StateFlow<BookingFormState> = _bookingState.asStateFlow()

    private val _whatsAppDialog = MutableStateFlow<WhatsAppDialogState?>(null)
    val whatsAppDialog: StateFlow<WhatsAppDialogState?> = _whatsAppDialog.asStateFlow()

    // Official WhatsApp number from configuration: 081324782858
    private val _configuredWhatsAppNumber = MutableStateFlow(WhatsAppConfig.OFFICIAL_PHONE_DISPLAY)
    val configuredWhatsAppNumber: StateFlow<String> = _configuredWhatsAppNumber.asStateFlow()

    // URL to open externally (e.g. Google Maps)
    private val _openExternalUrl = MutableStateFlow<String?>(null)
    val openExternalUrl: StateFlow<String?> = _openExternalUrl.asStateFlow()

    // Unread count indicator for floating button
    private val _unreadCount = MutableStateFlow(1)
    val unreadCount: StateFlow<Int> = _unreadCount.asStateFlow()

    val menuOptions: List<MenuOption> get() = repository.mainMenuOptions

    init {
        initGreeting()
    }

    private fun initGreeting() {
        if (_messages.value.isEmpty()) {
            _messages.value = listOf(repository.getInitialGreeting())
        }
    }

    fun openChat() {
        _isChatOpen.value = true
        _unreadCount.value = 0
    }

    fun closeChat() {
        _isChatOpen.value = false
    }

    fun onInputChanged(text: String) {
        _inputMessage.value = text
    }

    fun sendMessage(text: String? = null) {
        val query = (text ?: _inputMessage.value).trim()
        if (query.isBlank()) return

        _inputMessage.value = ""

        val userMsg = ChatMessage(
            sender = SenderType.USER,
            text = query
        )
        _messages.value = _messages.value + userMsg

        viewModelScope.launch {
            _isTyping.value = true
            delay(450)
            val botResponse = repository.processUserQuery(query)
            _messages.value = _messages.value + botResponse
            _isTyping.value = false
        }
    }

    fun selectMenu(menuId: MenuId) {
        val userSelectionMsg = ChatMessage(
            sender = SenderType.USER,
            text = "${menuId.optionNumber}. ${menuId.title}"
        )
        _messages.value = _messages.value + userSelectionMsg

        when (menuId) {
            MenuId.BOOKING_JADWAL -> {
                viewModelScope.launch {
                    _isTyping.value = true
                    delay(350)
                    val botResponse = repository.handleMenuSelection(menuId)
                    _messages.value = _messages.value + botResponse
                    _isTyping.value = false
                    _showBookingModal.value = true
                }
            }
            MenuId.HUBUNGI_ADMIN -> {
                viewModelScope.launch {
                    _isTyping.value = true
                    delay(350)
                    val botResponse = repository.handleMenuSelection(menuId)
                    _messages.value = _messages.value + botResponse
                    _isTyping.value = false
                    // Also trigger WhatsApp dialog/launcher
                    onWhatsAppClick()
                }
            }
            else -> {
                viewModelScope.launch {
                    _isTyping.value = true
                    delay(450)
                    val botResponse = repository.handleMenuSelection(menuId)
                    _messages.value = _messages.value + botResponse
                    _isTyping.value = false
                }
            }
        }
    }

    fun selectQuickReply(reply: QuickReply) {
        when (reply.payloadText) {
            "FORM_BOOKING" -> {
                _showBookingModal.value = true
            }
            "OPEN_MAPS" -> {
                _openExternalUrl.value = WhatsAppConfig.GOOGLE_MAPS_URL
            }
            else -> {
                sendMessage(reply.payloadText)
            }
        }
    }

    fun clearOpenExternalUrl() {
        _openExternalUrl.value = null
    }

    fun openGoogleMaps() {
        _openExternalUrl.value = WhatsAppConfig.GOOGLE_MAPS_URL
    }

    fun restartChat() {
        _messages.value = listOf(repository.getInitialGreeting())
    }

    fun openBookingModal() {
        _showBookingModal.value = true
    }

    fun closeBookingModal() {
        _showBookingModal.value = false
    }

    fun updateBookingState(update: BookingFormState) {
        _bookingState.value = update
    }

    fun submitBookingForm() {
        val currentState = _bookingState.value
        _showBookingModal.value = false

        val confirmMsg = repository.generateBookingConfirmation(currentState)
        _messages.value = _messages.value + confirmMsg

        _bookingState.value = BookingFormState()
    }

    fun onWhatsAppClick(customTopic: String? = null) {
        val defaultText = if (!customTopic.isNullOrBlank() && customTopic != "Konsultasi Langsung") {
            "Halo GUN AC MOBIL, saya ingin bertanya tentang $customTopic."
        } else {
            WhatsAppConfig.DEFAULT_PREFILL_TEXT
        }

        val url = WhatsAppConfig.buildWaMeUrl(
            number = WhatsAppConfig.OFFICIAL_PHONE_INTERNATIONAL,
            prefillText = defaultText
        )

        _openExternalUrl.value = url
    }

    fun dismissWhatsAppDialog() {
        _whatsAppDialog.value = null
    }

    fun setConfiguredWhatsAppNumber(newNumber: String) {
        _configuredWhatsAppNumber.value = newNumber.trim()
    }
}
