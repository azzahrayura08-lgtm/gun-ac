package com.example.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.data.config.WhatsAppConfig

object IntentHelper {

    /**
     * Membuka aplikasi WhatsApp langsung ke ruang obrolan nomor bengkel GUN AC MOBIL (6281324782858).
     *
     * Berdasarkan verifikasi pengujian pengguna:
     * Tautan https://wa.me/6281324782858 terbukti berhasil membuka obrolan WhatsApp secara langsung.
     *
     * Urutan Prioritas Peluncuran:
     * 1. URL wa.me dengan teks (https://wa.me/6281324782858?text=...) dengan target package com.whatsapp.
     * 2. URL wa.me langsung (https://wa.me/6281324782858) dengan target package com.whatsapp.
     * 3. URL wa.me dengan teks secara native Android Intent ACTION_VIEW (menggunakan App Links sistem Android).
     * 4. URL wa.me langsung (https://wa.me/6281324782858) secara native Android Intent ACTION_VIEW.
     * 5. Endpoint resmi https://api.whatsapp.com/send?phone=6281324782858&text=...
     * 6. Deep link whatsapp://send?phone=6281324782858&text=...
     */
    fun openWhatsApp(
        context: Context,
        phoneNumber: String = WhatsAppConfig.OFFICIAL_PHONE_INTERNATIONAL,
        message: String = WhatsAppConfig.DEFAULT_PREFILL_TEXT
    ) {
        val sanitizedPhone = phoneNumber.replace("+", "").replace("-", "").replace(" ", "").trim()
        val textToUse = if (message.isBlank()) WhatsAppConfig.DEFAULT_PREFILL_TEXT else message
        val encodedText = WhatsAppConfig.encodeUriComponent(textToUse)

        // 1. Tautan wa.me dengan teks pesan pembuka otomatis
        val waMeWithTextUri = Uri.parse("https://wa.me/$sanitizedPhone?text=$encodedText")

        // 2. Tautan wa.me langsung ke nomor tujuan (terbukti berhasil membuka obrolan di pengujian user)
        val waMeDirectUri = Uri.parse("https://wa.me/$sanitizedPhone")

        // 3. Tautan api.whatsapp.com
        val apiWhatsAppUri = Uri.parse("https://api.whatsapp.com/send?phone=$sanitizedPhone&text=$encodedText")

        // 4. Skema deep link whatsapp://
        val deepLinkUri = Uri.parse("whatsapp://send?phone=$sanitizedPhone&text=$encodedText")

        // LANGKAH 1 (PRIORITAS UTAMA):
        // Buka https://wa.me/... dengan teks terisi langsung ke paket WhatsApp Messenger (com.whatsapp)
        try {
            val intent = Intent(Intent.ACTION_VIEW, waMeWithTextUri).apply {
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        } catch (_: ActivityNotFoundException) {
            // Lanjut ke percobaan berikutnya
        } catch (_: Exception) {
            // Lanjut ke percobaan berikutnya
        }

        // LANGKAH 2:
        // Buka https://wa.me/6281324782858 langsung ke WhatsApp Messenger (com.whatsapp)
        try {
            val intent = Intent(Intent.ACTION_VIEW, waMeDirectUri).apply {
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        } catch (_: ActivityNotFoundException) {
            // Lanjut ke percobaan berikutnya
        } catch (_: Exception) {
            // Lanjut ke percobaan berikutnya
        }

        // LANGKAH 3 (STANDAR ANDROID APP LINKS):
        // Menggunakan Android Intent ACTION_VIEW dengan tautan wa.me (mekanisme yang sama seperti di Chrome)
        try {
            val intent = Intent(Intent.ACTION_VIEW, waMeWithTextUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        } catch (_: ActivityNotFoundException) {
            // Lanjut ke percobaan berikutnya
        } catch (_: Exception) {
            // Lanjut ke percobaan berikutnya
        }

        // LANGKAH 4:
        // Tautan wa.me direct secara native ACTION_VIEW
        try {
            val intent = Intent(Intent.ACTION_VIEW, waMeDirectUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        } catch (_: ActivityNotFoundException) {
            // Lanjut ke api.whatsapp.com
        } catch (_: Exception) {
            // Lanjut ke api.whatsapp.com
        }

        // LANGKAH 5:
        // Menggunakan api.whatsapp.com dengan target com.whatsapp
        try {
            val intent = Intent(Intent.ACTION_VIEW, apiWhatsAppUri).apply {
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        } catch (_: ActivityNotFoundException) {
            // Lanjut ke deep link
        } catch (_: Exception) {
            // Lanjut ke deep link
        }

        // LANGKAH 6:
        // Coba deep link whatsapp://send ke com.whatsapp
        try {
            val intent = Intent(Intent.ACTION_VIEW, deepLinkUri).apply {
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        } catch (_: ActivityNotFoundException) {
            // Lanjut ke whatsapp:// tanpa package
        } catch (_: Exception) {
            // Lanjut ke whatsapp:// tanpa package
        }

        // LANGKAH 7:
        // Coba deep link whatsapp:// tanpa penguncian package
        try {
            val intent = Intent(Intent.ACTION_VIEW, deepLinkUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                context,
                "Aplikasi WhatsApp tidak dapat dibuka. Silakan hubungi 081324782858.",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "Gagal membuka obrolan WhatsApp: ${e.localizedMessage ?: "Terjadi kesalahan"}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    /**
     * Membuka aplikasi Google Maps langsung menuju lokasi bengkel resmi
     */
    fun openGoogleMaps(
        context: Context,
        query: String = "GUN AC MOBIL, Jl. Letjen S. Parman, Pasar Sayur Pabuaran, Cirebon Timur"
    ) {
        val encodedQuery = Uri.encode(query)

        // 1. Prioritas utama: Buka langsung aplikasi Google Maps resmi via geo URI
        try {
            val mapsIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("geo:0,0?q=$encodedQuery")
                setPackage("com.google.android.apps.maps")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(mapsIntent)
            return
        } catch (_: ActivityNotFoundException) {
            // Google Maps app tidak tersedia, lanjut ke fallback web
        } catch (_: Exception) {
            // Lanjut ke fallback web
        }

        // 2. Fallback: Buka URL pencarian Google Maps via browser tanpa perantara skip
        try {
            val browserIntent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(WhatsAppConfig.GOOGLE_MAPS_URL)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(browserIntent)
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "Tidak dapat membuka peta Google Maps.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
