package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.config.WhatsAppConfig
import com.example.ui.components.BookingFormDialog
import com.example.ui.components.ChatbotOverlay
import com.example.ui.components.GunAcHomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.IntentHelper
import com.example.viewmodel.GunAcViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                GunAcApp()
            }
        }
    }
}

@Composable
fun GunAcApp(
    viewModel: GunAcViewModel = viewModel()
) {
    val context = LocalContext.current
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val isChatOpen by viewModel.isChatOpen.collectAsStateWithLifecycle()
    val isTyping by viewModel.isTyping.collectAsStateWithLifecycle()
    val inputMessage by viewModel.inputMessage.collectAsStateWithLifecycle()
    val showBookingModal by viewModel.showBookingModal.collectAsStateWithLifecycle()
    val bookingState by viewModel.bookingState.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadCount.collectAsStateWithLifecycle()
    val openExternalUrl by viewModel.openExternalUrl.collectAsStateWithLifecycle()

    // Menangani aksi eksternal: Google Maps atau WhatsApp Intent
    LaunchedEffect(openExternalUrl) {
        openExternalUrl?.let { url ->
            when {
                url.contains("google.com/maps") || url.startsWith("geo:") -> {
                    IntentHelper.openGoogleMaps(context)
                }
                url.contains("wa.me") || url.contains("whatsapp") -> {
                    IntentHelper.openWhatsApp(
                        context = context,
                        message = WhatsAppConfig.DEFAULT_PREFILL_TEXT
                    )
                }
                else -> {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    } catch (_: Exception) {}
                }
            }
            viewModel.clearOpenExternalUrl()
        }
    }

    // Tangani tombol back perangkat saat dialog booking atau chatbot sedang dibuka
    BackHandler(enabled = isChatOpen || showBookingModal) {
        when {
            showBookingModal -> viewModel.closeBookingModal()
            isChatOpen -> viewModel.closeChat()
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Tampilan Utama Website Bengkel GUN AC MOBIL
            GunAcHomeScreen(
                unreadCount = unreadCount,
                onOpenChatbot = { viewModel.openChat() },
                onSelectMenuFromHome = { menuId ->
                    viewModel.openChat()
                    viewModel.selectMenu(menuId)
                },
                onOpenBookingDialog = { viewModel.openBookingModal() },
                onWhatsAppClick = { customTopic ->
                    IntentHelper.openWhatsApp(
                        context = context,
                        message = WhatsAppConfig.createDefaultGreetingMessage(customTopic)
                    )
                },
                onOpenMaps = {
                    IntentHelper.openGoogleMaps(context)
                }
            )

            // Jendela Chatbot Mengambang (Pojok Kanan Bawah)
            ChatbotOverlay(
                isVisible = isChatOpen,
                messages = messages,
                isTyping = isTyping,
                inputMessage = inputMessage,
                menuOptions = viewModel.menuOptions,
                onClose = { viewModel.closeChat() },
                onInputChanged = { viewModel.onInputChanged(it) },
                onSendMessage = { viewModel.sendMessage(it) },
                onSelectMenu = { viewModel.selectMenu(it) },
                onSelectQuickReply = { viewModel.selectQuickReply(it) },
                onRestartChat = { viewModel.restartChat() },
                onWhatsAppClick = { customTopic ->
                    IntentHelper.openWhatsApp(
                        context = context,
                        message = WhatsAppConfig.createDefaultGreetingMessage(customTopic)
                    )
                },
                onOpenBookingForm = { viewModel.openBookingModal() },
                onOpenMaps = {
                    IntentHelper.openGoogleMaps(context)
                }
            )

            // Dialog Formulir Booking Servis
            if (showBookingModal) {
                BookingFormDialog(
                    formState = bookingState,
                    onStateChange = { viewModel.updateBookingState(it) },
                    onSubmit = { viewModel.submitBookingForm() },
                    onDismiss = { viewModel.closeBookingModal() }
                )
            }
        }
    }
}
