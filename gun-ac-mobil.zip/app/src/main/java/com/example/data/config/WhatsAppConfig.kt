package com.example.data.config

import java.net.URLEncoder

/**
 * Konfigurasi Integrasi WhatsApp & Kontak Resmi GUN AC MOBIL
 *
 * Data Resmi:
 * - Alamat: Jl. Letjen S. Parman, Pasar Sayur Pabuaran, Cirebon Timur.
 * - WhatsApp: 081324782858 (https://wa.me/6281324782858)
 * - Google Maps: https://www.google.com/maps/search/?api=1&query=Jl.+Letjen+S.+Parman+Pasar+Sayur+Pabuaran
 * - Pesan Pembuka Otomatis: "Halo GUN AC MOBIL, saya ingin bertanya tentang layanan AC mobil."
 */
object WhatsAppConfig {
    // Nomor WhatsApp Resmi
    const val OFFICIAL_PHONE_DISPLAY = "081324782858"
    const val OFFICIAL_PHONE_INTERNATIONAL = "6281324782858"

    // Alamat bengkel resmi GUN AC MOBIL
    const val WORKSHOP_NAME = "GUN AC MOBIL"
    const val WORKSHOP_ADDRESS = "Jl. Letjen S. Parman, Pasar Sayur Pabuaran, Cirebon Timur."
    const val WORKSHOP_HOURS = "Senin - Sabtu: 08:00 - 17:00 | Minggu: 09:00 - 15:00 WIB"

    // URL Google Maps Resmi menuju GUN AC MOBIL Pasar Sayur Pabuaran
    const val GOOGLE_MAPS_URL = "https://www.google.com/maps/search/?api=1&query=GUN+AC+MOBIL+Jl+Letjen+S+Parman+Pasar+Sayur+Pabuaran+Cirebon+Timur"

    // Pesan pembuka otomatis resmi sesuai instruksi wajib: "Halo GUN AC MOBIL"
    const val DEFAULT_PREFILL_TEXT = "Halo GUN AC MOBIL"

    // Deep link URI resmi sesuai instruksi:
    // whatsapp://send?phone=6281324782858&text=Halo%20GUN%20AC%20MOBIL
    const val OFFICIAL_DEEP_LINK = "whatsapp://send?phone=6281324782858&text=Halo%20GUN%20AC%20MOBIL"

    /**
     * Membangun Deep Link WhatsApp resmi: whatsapp://send?phone=...&text=...
     */
    fun buildDeepLinkUrl(
        number: String = OFFICIAL_PHONE_INTERNATIONAL,
        prefillText: String = DEFAULT_PREFILL_TEXT
    ): String {
        val sanitizedNumber = if (number.startsWith("0")) {
            "62" + number.substring(1)
        } else {
            number.replace("+", "").replace("-", "").replace(" ", "").trim()
        }
        val encodedText = encodeUriComponent(prefillText)
        return "whatsapp://send?phone=$sanitizedNumber&text=$encodedText"
    }

    /**
     * Membangun URL WhatsApp Click-to-Chat resmi (wa.me)
     * Format: https://wa.me/6281324782858?text=Halo%20GUN%20AC%20MOBIL
     */
    fun buildWaMeUrl(
        number: String = OFFICIAL_PHONE_INTERNATIONAL,
        prefillText: String = DEFAULT_PREFILL_TEXT
    ): String {
        val sanitizedNumber = if (number.startsWith("0")) {
            "62" + number.substring(1)
        } else {
            number.replace("+", "").replace("-", "").replace(" ", "").trim()
        }
        val encodedText = encodeUriComponent(prefillText)
        return "https://wa.me/$sanitizedNumber?text=$encodedText"
    }

    /**
     * Helper encoding persen yang kompatibel di Android dan JVM unit test
     */
    fun encodeUriComponent(text: String): String {
        return text.map { char ->
            when (char) {
                in 'a'..'z', in 'A'..'Z', in '0'..'9', '-', '_', '.', '~' -> char.toString()
                ' ' -> "%20"
                ',' -> "%2C"
                ':' -> "%3A"
                '/' -> "%2F"
                '?' -> "%3F"
                '#' -> "%23"
                '[' -> "%5B"
                ']' -> "%5D"
                '@' -> "%40"
                '!' -> "%21"
                '$' -> "%24"
                '&' -> "%26"
                '\'' -> "%27"
                '(' -> "%28"
                ')' -> "%29"
                '*' -> "%2A"
                '+' -> "%2B"
                ';' -> "%3B"
                '=' -> "%3D"
                else -> {
                    val bytes = char.toString().toByteArray(Charsets.UTF_8)
                    bytes.joinToString("") { "%" + "%02X".format(it) }
                }
            }
        }.joinToString("")
    }

    /**
     * Template pesan awal saat pelanggan membuka WhatsApp admin
     */
    fun createDefaultGreetingMessage(topic: String? = null): String {
        return if (!topic.isNullOrBlank()) {
            "Halo GUN AC MOBIL, saya ingin bertanya tentang $topic."
        } else {
            DEFAULT_PREFILL_TEXT
        }
    }
}

/**
 * Struktur Arsitektur untuk Integrasi WhatsApp Business Cloud API (Meta API)
 * Disiapkan agar backend/webhook siap menerima dan membalas payload WhatsApp.
 */
data class WhatsAppCloudApiMessage(
    val messagingProduct: String = "whatsapp",
    val recipientType: String = "individual",
    val to: String,
    val type: String = "text",
    val text: WhatsAppTextMessageBody? = null,
    val interactive: WhatsAppInteractiveMessage? = null
)

data class WhatsAppTextMessageBody(
    val body: String,
    val previewUrl: Boolean = false
)

data class WhatsAppInteractiveMessage(
    val type: String = "button",
    val body: WhatsAppTextMessageBody,
    val action: WhatsAppInteractiveAction
)

data class WhatsAppInteractiveAction(
    val buttons: List<WhatsAppInteractiveButton>
)

data class WhatsAppInteractiveButton(
    val type: String = "reply",
    val reply: WhatsAppButtonReply
)

data class WhatsAppButtonReply(
    val id: String,
    val title: String
)
