package com.example.data.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class SenderType {
    BOT, USER, SYSTEM
}

enum class MenuId(val optionNumber: Int, val title: String) {
    KONSULTASI_RUSAK(1, "Konsultasi kerusakan AC mobil"),
    BOOKING_JADWAL(2, "Booking jadwal servis"),
    INFORMASI_LAYANAN(3, "Informasi layanan bengkel"),
    LOKASI_OPERASIONAL(4, "Lokasi dan jam operasional"),
    HUBUNGI_ADMIN(5, "Hubungi admin")
}

data class MenuOption(
    val id: MenuId,
    val number: Int,
    val title: String,
    val subtitle: String,
    val iconKey: String
)

sealed class ChatPayload {
    data class DiagnosisGuide(
        val symptoms: List<DiagnosisSymptom>
    ) : ChatPayload()

    data class BookingSummary(
        val bookingCode: String,
        val customerName: String,
        val carInfo: String,
        val servicePackage: String,
        val appointmentDate: String,
        val appointmentTime: String
    ) : ChatPayload()

    data class ServiceInfo(
        val highlights: List<String>,
        val operationalHours: String,
        val warrantyInfo: String
    ) : ChatPayload()

    data class LocationAndHours(
        val address: String,
        val operationalHours: String,
        val mapsUrl: String,
        val notes: String
    ) : ChatPayload()

    data class AdminContact(
        val phoneNumber: String,
        val note: String,
        val address: String,
        val mapsUrl: String
    ) : ChatPayload()
}

data class DiagnosisSymptom(
    val title: String,
    val probableCause: String,
    val recommendation: String
)

data class QuickReply(
    val label: String,
    val payloadText: String
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: SenderType,
    val text: String,
    val timestamp: String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
    val showMainMenu: Boolean = false,
    val quickReplies: List<QuickReply> = emptyList(),
    val payload: ChatPayload? = null,
    val showWhatsAppButton: Boolean = false
)

data class BookingFormState(
    val customerName: String = "",
    val phoneNumber: String = "",
    val carBrandModel: String = "",
    val carYear: String = "",
    val servicePackage: String = "Servis Komprehensif & Cuci Evaporator",
    val selectedDate: String = "Besok",
    val selectedTime: String = "10:00 WIB",
    val customerNotes: String = ""
)
