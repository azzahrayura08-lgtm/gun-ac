package com.example.data.repository

import com.example.data.config.WhatsAppConfig
import com.example.data.model.BookingFormState
import com.example.data.model.ChatMessage
import com.example.data.model.ChatPayload
import com.example.data.model.DiagnosisSymptom
import com.example.data.model.MenuId
import com.example.data.model.MenuOption
import com.example.data.model.QuickReply
import com.example.data.model.SenderType
import java.util.UUID

class ChatbotRepository {

    val mainMenuOptions: List<MenuOption> = listOf(
        MenuOption(
            id = MenuId.KONSULTASI_RUSAK,
            number = 1,
            title = "Konsultasi kerusakan AC mobil",
            subtitle = "Diagnosa gejala AC tidak dingin, berbau, atau berbunyi",
            iconKey = "diagnose"
        ),
        MenuOption(
            id = MenuId.BOOKING_JADWAL,
            number = 2,
            title = "Booking jadwal servis",
            subtitle = "Pilih tanggal servis agar tidak perlu antre di bengkel",
            iconKey = "booking"
        ),
        MenuOption(
            id = MenuId.INFORMASI_LAYANAN,
            number = 3,
            title = "Informasi layanan bengkel",
            subtitle = "Fasilitas flushing komputerisasi & perawatan spesialis",
            iconKey = "service"
        ),
        MenuOption(
            id = MenuId.LOKASI_OPERASIONAL,
            number = 4,
            title = "Lokasi dan jam operasional",
            subtitle = "Pasar Sayur Pabuaran & navigasi Google Maps",
            iconKey = "location"
        ),
        MenuOption(
            id = MenuId.HUBUNGI_ADMIN,
            number = 5,
            title = "Hubungi admin",
            subtitle = "Buka chat WhatsApp resmi admin",
            iconKey = "whatsapp"
        )
    )

    fun getInitialGreeting(): ChatMessage {
        return ChatMessage(
            sender = SenderType.BOT,
            text = "Selamat datang di GUN AC MOBIL. Ada yang bisa kami bantu?\n\nSilakan pilih salah satu opsi menu di bawah atau ketik langsung pertanyaan Anda seputar AC mobil:",
            showMainMenu = true,
            quickReplies = listOf(
                QuickReply("1. Konsultasi Kerusakan", "1"),
                QuickReply("2. Booking Servis", "2"),
                QuickReply("3. Layanan Bengkel", "3"),
                QuickReply("4. Lokasi & Jam", "4"),
                QuickReply("5. Hubungi Admin", "5")
            )
        )
    }

    fun handleMenuSelection(menuId: MenuId): ChatMessage {
        return when (menuId) {
            MenuId.KONSULTASI_RUSAK -> createGeneralDiagnosisOverview()
            MenuId.BOOKING_JADWAL -> createBookingPromptMessage()
            MenuId.INFORMASI_LAYANAN -> createServicesInfoMessage()
            MenuId.LOKASI_OPERASIONAL -> createLocationAndHoursMessage()
            MenuId.HUBUNGI_ADMIN -> createAdminContactMessage()
        }
    }

    /**
     * Membaca dan memproses pertanyaan bebas pelanggan berdasarkan kategori dan kata kunci bahasa Indonesia
     */
    fun processUserQuery(query: String): ChatMessage {
        val trimmed = query.trim().lowercase()

        // 1. Pilihan nomor menu langsung
        when (trimmed) {
            "1", "menu 1", "satu", "konsultasi", "konsultasi rusak", "kerusakan" -> return createGeneralDiagnosisOverview()
            "2", "menu 2", "dua", "booking", "booking jadwal", "jadwal" -> return createBookingPromptMessage()
            "3", "menu 3", "tiga", "info", "informasi layanan", "layanan" -> return createServicesInfoMessage()
            "4", "menu 4", "empat", "lokasi", "jam", "operasional", "alamat" -> return createLocationAndHoursMessage()
            "5", "menu 5", "lima", "admin", "hubungi admin", "wa", "whatsapp", "chat wa" -> return createAdminContactMessage()
        }

        // 2. Salam / Sapaan
        if (containsAny(trimmed, "halo", "hai", "hello", "assalamualaikum", "pagi", "siang", "sore", "malam", "tes", "test")) {
            return ChatMessage(
                sender = SenderType.BOT,
                text = "Halo! Senang menyapa Anda di GUN AC MOBIL. Kami adalah bengkel spesialis perbaikan dan perawatan AC mobil di Cirebon Timur.\n\nAda keluhan atau hal yang ingin Anda tanyakan seputar AC mobil Anda hari ini?",
                showMainMenu = true,
                quickReplies = listOf(
                    QuickReply("AC Tidak Dingin", "ac tidak dingin"),
                    QuickReply("Booking Servis", "2"),
                    QuickReply("Lokasi & Jam", "4"),
                    QuickReply("Hubungi Admin", "5")
                )
            )
        }

        // 3. Kategori Masalah Spesifik Sesuai Permintaan User:
        // Kategori 3A: AC hanya keluar angin (tidak dingin sama sekali / kompresor mati)
        if (containsAny(trimmed, "hanya keluar angin", "keluar angin saja", "cuma angin", "angin doang", "hanya hembusan angin", "tidak ada dingin sama sekali")) {
            return ChatMessage(
                sender = SenderType.BOT,
                text = "Berikut analisa awal untuk keluhan **AC hanya keluar angin / hembusan biasa**:\n\n" +
                        "• **Kemungkinan Penyebab:** Kompresor AC tidak berputar (magnetic clutch slip/mati), sekring/relay AC terputus, atau freon telah kosong sama sekali akibat kebocoran pada sistem.\n" +
                        "• **Saran Penanganan:** Perlu pengecekan tekanan freon menggunakan manifold gauge dan pemeriksaan kelistrikan kompresor.\n\n" +
                        "⚠️ *Catatan Teknisi: Indikasi di atas merupakan analisa awal berdasarkan gejala umum. Kepastian kerusakan memerlukan pemeriksaan langsung oleh teknisi kami di bengkel agar tidak salah penanganan.*",
                showWhatsAppButton = true,
                quickReplies = listOf(
                    QuickReply("Booking Jadwal Cek", "2"),
                    QuickReply("Lokasi Bengkel", "4"),
                    QuickReply("Chat Admin WhatsApp", "5")
                )
            )
        }

        // Kategori 3B: AC kadang dingin kadang panas (suhu tidak stabil / macet jadi panas)
        if (containsAny(trimmed, "kadang dingin kadang panas", "kadang dingin kadang tidak", "kadang panas", "hilang timbul", "mati nyala", "pas macet panas", "saat macet panas", "dingin cuma pas jalan", "dingin hanya jalan")) {
            return ChatMessage(
                sender = SenderType.BOT,
                text = "Berikut analisa awal untuk keluhan **AC kadang dingin kadang panas**:\n\n" +
                        "• **Kemungkinan Penyebab:** Putaran motor extra fan (kipas kondensor) mulai melemah sehingga pelepasan panas kondensor terganggu saat mobil berhenti/macet, kondensor kotor tersumbat debu, atau celah magnetic clutch kompresor sudah terlalu renggang saat mesin panas.\n" +
                        "• **Saran Penanganan:** Disarankan pembersihan kisi-kisi kondensor dan pengujian putaran motor extra fan.\n\n" +
                        "⚠️ *Catatan Teknisi: Indikasi ini adalah gambaran awal. Kepastian penyebab membutuhkan pengukuran langsung oleh teknisi bengkel GUN AC MOBIL.*",
                showWhatsAppButton = true,
                quickReplies = listOf(
                    QuickReply("Booking Jadwal Servis", "2"),
                    QuickReply("Tanya Admin WA", "5"),
                    QuickReply("Lokasi Bengkel", "4")
                )
            )
        }

        // Kategori 3C: AC berbau tidak sedap (apek / asam / jamur)
        if (containsAny(trimmed, "bau", "apek", "tidak sedap", "asam", "tengik", "bangkai", "bau apek", "kurang sedap")) {
            return ChatMessage(
                sender = SenderType.BOT,
                text = "Berikut analisa awal untuk keluhan **AC berbau tidak sedap / apek**:\n\n" +
                        "• **Kemungkinan Penyebab:** Evaporator lembap dan tertimbun jamur/bakteri, filter kabin kotor berdebu, atau ada kotoran sirkulasi yang terperangkap pada saluran udara.\n" +
                        "• **Saran Penanganan:** Tindakan pembersihan evaporator secara endoskopi (tanpa bongkar dashboard), penggantian filter kabin karbon, serta fogging sterilisasi kabin.\n\n" +
                        "⚠️ *Catatan Teknisi: Indikasi awal ini perlu dipastikan dengan memeriksa kebersihan filter kabin dan sirip evaporator di bengkel.*",
                showWhatsAppButton = true,
                quickReplies = listOf(
                    QuickReply("Booking Servis Cuci", "2"),
                    QuickReply("Konsultasi ke Admin", "5"),
                    QuickReply("Lokasi Bengkel", "4")
                )
            )
        }

        // Kategori 3D: AC berbunyi berisik / kasar / mendengung
        if (containsAny(trimmed, "bunyi", "berisik", "kasar", "mendengung", "berdecit", "suara kasar", "ngorok", "gemuruh")) {
            return ChatMessage(
                sender = SenderType.BOT,
                text = "Berikut analisa awal untuk keluhan **AC berbunyi berisik / kasar**:\n\n" +
                        "• **Kemungkinan Penyebab:** Bearing pulley kompresor sudah aus, oli pelumas kompresor telah kering atau kotor, v-belt kendur, atau piston internal kompresor mengalami keausan.\n" +
                        "• **Saran Penanganan:** Segera matikan tombol A/C saat mendengar suara kasar dan hindari pemakaian paksa agar kompresor tidak terkunci (*lock/macet total*). Segera lakukan pengecekan di bengkel.\n\n" +
                        "⚠️ *Catatan Teknisi: Diagnosa pasti hanya dapat ditentukan setelah teknisi memeriksa kompresor dan tali kipas secara langsung.*",
                showWhatsAppButton = true,
                quickReplies = listOf(
                    QuickReply("Jadwalkan Servis Segera", "2"),
                    QuickReply("Hubungi Admin WA", "5"),
                    QuickReply("Lokasi Bengkel", "4")
                )
            )
        }

        // Kategori 3E: AC mobil tidak dingin / kurang dingin / panas
        if (containsAny(trimmed, "tidak dingin", "kurang dingin", "panas", "gak dingin", "anget", "kurang nyes", "kurang sejuk")) {
            return ChatMessage(
                sender = SenderType.BOT,
                text = "Berikut analisa awal untuk keluhan **AC mobil tidak dingin / kurang dingin**:\n\n" +
                        "• **Kemungkinan Penyebab:** Tekanan freon berkurang akibat kebocoran halus pada sambungan pipa atau evaporator, filter kabin tersumbat debu tebal, sirip kondensor kotor, atau kompresor tidak memompa optimal.\n" +
                        "• **Saran Penanganan:** Pengecekan tekanan sirkulasi freon dengan manifold gauge dan uji deteksi kebocoran.\n\n" +
                        "⚠️ *Catatan Teknisi: Indikasi di atas merupakan gambaran umum. Diagnosa kepastian kerusakan dan solusi tepat harus melalui pemeriksaan fisik oleh teknisi GUN AC MOBIL.*",
                showWhatsAppButton = true,
                quickReplies = listOf(
                    QuickReply("Booking Pengecekan", "2"),
                    QuickReply("Lokasi & Rute", "4"),
                    QuickReply("Chat WhatsApp Admin", "5")
                )
            )
        }

        // Kategori 4: Perawatan AC mobil
        if (containsAny(trimmed, "perawatan", "merawat", "tips", "rutin", "ganti filter", "fogging", "kapan harus servis")) {
            return ChatMessage(
                sender = SenderType.BOT,
                text = "Panduan **Perawatan Rutin AC Mobil** agar awet & dingin optimal:\n\n" +
                        "1. **Filter Kabin:** Periksa atau ganti setiap 10.000 km agar aliran udara tidak terhambat dan udara tetap bersih.\n" +
                        "2. **Pembersihan Evaporator:** Cuci evaporator berkala setiap 6 - 12 bulan untuk mencegah jamur dan bau apek.\n" +
                        "3. **Kuras Freon & Oli Kompresor:** Lakukan flushing sirkulasi secara berkala agar kompresor tidak cepat panas dan terhindar dari gesekan aus.\n" +
                        "4. **Kebersihan Kabin:** Jaga kebersihan karpet mobil dan hindari merokok di dalam mobil saat AC menyala.\n\n" +
                        "Ingin melakukan perawatan berkala untuk mobil Anda?",
                showWhatsAppButton = true,
                quickReplies = listOf(
                    QuickReply("Booking Servis Perawatan", "2"),
                    QuickReply("Lokasi Bengkel", "4"),
                    QuickReply("Chat WhatsApp", "5")
                )
            )
        }

        // Kategori 5: Booking Servis
        if (containsAny(trimmed, "booking", "pesan", "reservasi", "antri", "daftar", "daftar servis", "mau servis", "jadwalkan")) {
            return createBookingPromptMessage()
        }

        // Kategori 6: Alamat Bengkel & Lokasi
        if (containsAny(trimmed, "alamat", "lokasi", "dimana", "maps", "rute", "pabuaran", "cirebon", "parman", "tempat")) {
            return createLocationAndHoursMessage()
        }

        // Kategori 7: Jam Operasional
        if (containsAny(trimmed, "jam", "buka", "tutup", "hari apa", "jadwal buka", "operasional", "kapan buka")) {
            return ChatMessage(
                sender = SenderType.BOT,
                text = "⏰ **Jam Operasional GUN AC MOBIL:**\n\n" +
                        "• **Senin - Sabtu:** 08:00 - 17:00 WIB\n" +
                        "• **Minggu:** 09:00 - 15:00 WIB\n\n" +
                        "📍 **Alamat:** ${WhatsAppConfig.WORKSHOP_ADDRESS}\n\n" +
                        "Kami siap melayani kebutuhan servis dan perawatan AC mobil Anda.",
                payload = ChatPayload.LocationAndHours(
                    address = WhatsAppConfig.WORKSHOP_ADDRESS,
                    operationalHours = WhatsAppConfig.WORKSHOP_HOURS,
                    mapsUrl = WhatsAppConfig.GOOGLE_MAPS_URL,
                    notes = "Patokan: Dekat Pasar Sayur Pabuaran, Cirebon Timur. Area bengkel luas dan nyaman."
                ),
                quickReplies = listOf(
                    QuickReply("Buka Google Maps", "OPEN_MAPS"),
                    QuickReply("Booking Servis", "2"),
                    QuickReply("Hubungi Admin", "5")
                ),
                showWhatsAppButton = true
            )
        }

        // Kategori 8: Jenis Layanan Bengkel
        if (containsAny(trimmed, "jenis layanan", "layanan", "fasilitas", "bisa apa saja", "spesialis", "perbaikan apa")) {
            return createServicesInfoMessage()
        }

        // Kategori 9: Admin / Hubungi WhatsApp
        if (containsAny(trimmed, "admin", "cs", "kontak", "wa", "whatsapp", "hubungi", "telepon", "bicara", "tanya langsung")) {
            return createAdminContactMessage()
        }

        // Kategori 10: Pertanyaan Harga (Direspons sopan tanpa membuat harga palsu)
        if (containsAny(trimmed, "harga", "biaya", "tarif", "ongkos", "berapa")) {
            return ChatMessage(
                sender = SenderType.BOT,
                text = "Untuk estimasi biaya servis yang akurat dan transparan sesuai kondisi serta tipe mobil Anda, silakan hubungi langsung Admin GUN AC MOBIL melalui WhatsApp. Tim kami siap membantu memberikan informasi yang jelas tanpa biaya tersembunyi.",
                showWhatsAppButton = true,
                quickReplies = listOf(
                    QuickReply("Konsultasi Kerusakan", "1"),
                    QuickReply("Booking Servis", "2"),
                    QuickReply("Lokasi Bengkel", "4"),
                    QuickReply("Chat WhatsApp Admin", "5")
                )
            )
        }

        // 11. Fallback (Pertanyaan belum dipahami) -> Merespons dengan sopan & tawarkan bantuan admin WhatsApp
        return ChatMessage(
            sender = SenderType.BOT,
            text = "Mohon maaf, kami belum sepenuhnya memahami pertanyaan Anda. Apakah yang Anda maksud terkait keluhan kerusakan AC, jadwal booking, atau lokasi bengkel?\n\nAnda juga dapat berkonsultasi langsung dengan tim teknisi dan admin kami melalui WhatsApp:",
            showMainMenu = true,
            showWhatsAppButton = true,
            quickReplies = listOf(
                QuickReply("1. Konsultasi Kerusakan", "1"),
                QuickReply("2. Booking Jadwal", "2"),
                QuickReply("3. Layanan Bengkel", "3"),
                QuickReply("4. Lokasi & Jam", "4"),
                QuickReply("5. Hubungi Admin WA", "5")
            )
        )
    }

    private fun createGeneralDiagnosisOverview(): ChatMessage {
        val symptoms = listOf(
            DiagnosisSymptom(
                title = "AC Tidak Dingin / Hanya Keluar Angin",
                probableCause = "Freon berkurang/habis akibat kebocoran, magnetic clutch kompresor aus, atau kelistrikan terputus.",
                recommendation = "Pemeriksaan tekanan manifold gauge dan uji fisik kompresor oleh teknisi."
            ),
            DiagnosisSymptom(
                title = "AC Mengeluarkan Bau Tidak Sedap / Apek",
                probableCause = "Evaporator lembap berjamur atau filter kabin kotor tersumbat debu.",
                recommendation = "Pembersihan evaporator endoskopi tanpa bongkar dashboard & sterilisasi kabin."
            ),
            DiagnosisSymptom(
                title = "AC Berbunyi Berisik / Kasar",
                probableCause = "Bearing kompresor aus, oli pelumas kompresor kering, atau v-belt kendor.",
                recommendation = "Segera matikan tombol AC agar kompresor tidak macet, lakukan pengecekan di bengkel."
            ),
            DiagnosisSymptom(
                title = "AC Kadang Dingin Kadang Panas",
                probableCause = "Motor extra fan melemah saat macet atau magnetic clutch mengalami slip saat panas.",
                recommendation = "Pengecekan putaran extra fan radiator/kondensor dan kelonggaran kopling kompresor."
            )
        )

        return ChatMessage(
            sender = SenderType.BOT,
            text = "Berikut panduan umum analisa awal keluhan AC mobil di GUN AC MOBIL:\n\n" +
                    "⚠️ *Catatan Penting: Indikasi di bawah merupakan analisa awal. Diagnosa kerusakan yang pasti memerlukan pemeriksaan fisik langsung oleh teknisi kami.*",
            payload = ChatPayload.DiagnosisGuide(symptoms),
            quickReplies = listOf(
                QuickReply("Booking Jadwal Cek", "2"),
                QuickReply("Lokasi & Jam Buka", "4"),
                QuickReply("Konsultasi ke Admin WA", "5")
            ),
            showWhatsAppButton = true
        )
    }

    private fun createBookingPromptMessage(): ChatMessage {
        return ChatMessage(
            sender = SenderType.BOT,
            text = "Ingin servis tanpa perlu mengantre lama di bengkel? Anda dapat mengisi form booking jadwal di bawah ini secara instan atau langsung hubungi admin WhatsApp kami:\n\n" +
                    "Kami akan menyiapkan stall pengerjaan untuk kenyamanan Anda di bengkel GUN AC MOBIL.",
            quickReplies = listOf(
                QuickReply("Buka Form Booking", "FORM_BOOKING"),
                QuickReply("Lokasi Bengkel", "4"),
                QuickReply("Chat WhatsApp Admin", "5")
            ),
            showWhatsAppButton = true
        )
    }

    private fun createServicesInfoMessage(): ChatMessage {
        val highlights = listOf(
            "Perawatan Berkala: Penggantian filter kabin, sterilisasi fogging bakteri, dan pembersihan blower.",
            "Flushing Sirkulasi Otomatis: Pengurasan oli kompresor lama dan pengisian oli sintetik baru berbasis mesin.",
            "Cuci Evaporator Endoskopi: Pembersihan kisi evaporator tanpa membongkar dashboard mobil.",
            "Perbaikan Kompresor & Magnetic Clutch: Penanganan bunyi kasar, kompresor aus, dan ganti bearing.",
            "Uji Deteksi Kebocoran: Pengecekan menyeluruh pada selang, sambungan nepel, dan kondensor.",
            "Fasilitas Nyaman: Ruang tunggu ber-AC, Free WiFi, dan monitor pantau pengerjaan."
        )

        return ChatMessage(
            sender = SenderType.BOT,
            text = "Tentang **Jenis Layanan Bengkel GUN AC MOBIL**:\n" +
                    "Kami adalah bengkel spesialis perbaikan dan perawatan sistem pendingin kabin mobil Jepang, Eropa, dan Korea dengan standar pengerjaan profesional dan bergaransi.",
            payload = ChatPayload.ServiceInfo(
                highlights = highlights,
                operationalHours = WhatsAppConfig.WORKSHOP_HOURS,
                warrantyInfo = "Garansi servis dingin dengan bukti kartu servis resmi."
            ),
            quickReplies = listOf(
                QuickReply("Booking Jadwal Servis", "2"),
                QuickReply("Lokasi & Jam Buka", "4"),
                QuickReply("Hubungi Admin WA", "5")
            ),
            showWhatsAppButton = true
        )
    }

    private fun createLocationAndHoursMessage(): ChatMessage {
        return ChatMessage(
            sender = SenderType.BOT,
            text = "📍 **Lokasi Resmi & Jam Operasional GUN AC MOBIL:**\n\n" +
                    "• **Alamat:**\n${WhatsAppConfig.WORKSHOP_ADDRESS}\n\n" +
                    "• **Jam Operasional:**\n${WhatsAppConfig.WORKSHOP_HOURS}\n\n" +
                    "Silakan klik tombol di bawah untuk membuka rute langsung di aplikasi Google Maps atau chat admin via WhatsApp:",
            payload = ChatPayload.LocationAndHours(
                address = WhatsAppConfig.WORKSHOP_ADDRESS,
                operationalHours = WhatsAppConfig.WORKSHOP_HOURS,
                mapsUrl = WhatsAppConfig.GOOGLE_MAPS_URL,
                notes = "Patokan: Dekat Pasar Sayur Pabuaran, Cirebon Timur. Akses mudah dan area parkir aman."
            ),
            quickReplies = listOf(
                QuickReply("Buka Google Maps", "OPEN_MAPS"),
                QuickReply("Booking Servis", "2"),
                QuickReply("Hubungi Admin", "5")
            ),
            showWhatsAppButton = true
        )
    }

    private fun createAdminContactMessage(): ChatMessage {
        return ChatMessage(
            sender = SenderType.BOT,
            text = "Silakan hubungi tim Admin & Teknisi GUN AC MOBIL secara langsung melalui WhatsApp untuk konsultasi dan respon cepat.\n\n" +
                    "Pesan otomatis sudah disiapkan untuk kenyamanan Anda:",
            payload = ChatPayload.AdminContact(
                phoneNumber = WhatsAppConfig.OFFICIAL_PHONE_DISPLAY,
                note = "Pesan pembuka otomatis: \"${WhatsAppConfig.DEFAULT_PREFILL_TEXT}\"",
                address = WhatsAppConfig.WORKSHOP_ADDRESS,
                mapsUrl = WhatsAppConfig.GOOGLE_MAPS_URL
            ),
            showWhatsAppButton = true,
            quickReplies = listOf(
                QuickReply("Konsultasi Kerusakan", "1"),
                QuickReply("Booking Jadwal", "2"),
                QuickReply("Lokasi & Jam", "4")
            )
        )
    }

    fun generateBookingConfirmation(state: BookingFormState): ChatMessage {
        val bookingCode = "GUN-" + UUID.randomUUID().toString().take(6).uppercase()
        val summary = ChatPayload.BookingSummary(
            bookingCode = bookingCode,
            customerName = state.customerName.ifBlank { "Pelanggan Yth." },
            carInfo = "${state.carBrandModel} (${state.carYear.ifBlank { "Tahun -" }})",
            servicePackage = state.servicePackage,
            appointmentDate = state.selectedDate,
            appointmentTime = state.selectedTime
        )

        return ChatMessage(
            sender = SenderType.BOT,
            text = "Pendaftaran Booking Servis Berhasil Tercatat!\n\n" +
                    "• **Kode Booking:** $bookingCode\n" +
                    "• **Nama:** ${summary.customerName}\n" +
                    "• **Mobil:** ${summary.carInfo}\n" +
                    "• **Layanan:** ${summary.servicePackage}\n" +
                    "• **Jadwal:** ${summary.appointmentDate}, Pukul ${summary.appointmentTime}\n" +
                    "• **Lokasi:** ${WhatsAppConfig.WORKSHOP_ADDRESS}\n\n" +
                    "Teknisi kami siap menyambut kedatangan Anda. Anda dapat mengirimkan konfirmasi kode booking ini ke WhatsApp resmi admin.",
            payload = summary,
            showWhatsAppButton = true,
            quickReplies = listOf(
                QuickReply("Buka Google Maps", "OPEN_MAPS"),
                QuickReply("Lihat Info Bengkel", "3"),
                QuickReply("Chat WhatsApp Admin", "5")
            )
        )
    }

    private fun containsAny(text: String, vararg keywords: String): Boolean {
        return keywords.any { text.contains(it, ignoreCase = true) }
    }
}
