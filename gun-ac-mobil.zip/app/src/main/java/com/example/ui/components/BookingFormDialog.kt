package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CarRepair
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.BookingFormState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingFormDialog(
    formState: BookingFormState,
    onStateChange: (BookingFormState) -> Unit,
    onSubmit: () -> Unit,
    onDismiss: () -> Unit
) {
    val serviceOptions = listOf(
        "Servis Ringan + Cuci Blower & Filter Kabin",
        "Kuras & Pengisian Freon R134a + Oli Kompresor",
        "Cuci Evaporator Endoskopi (Tanpa Bongkar)",
        "Overhaul Kompresor & Perbaikan Sistem",
        "Pengecekan Komprehensif & Uji Kebocoran"
    )

    val dateOptions = listOf("Hari Ini", "Besok", "Lusa", "Pilih Hari Kerja Minggu Ini")
    val timeOptions = listOf("09:00 WIB", "10:30 WIB", "13:00 WIB", "14:30 WIB", "16:00 WIB")

    var packageExpanded by remember { mutableStateOf(false) }
    var dateExpanded by remember { mutableStateOf(false) }
    var timeExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("booking_form_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Booking Servis AC",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Daftarkan jadwal servis AC Anda untuk menghindari antrean di bengkel GUN AC MOBIL.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Nama Pemilik
                OutlinedTextField(
                    value = formState.customerName,
                    onValueChange = { onStateChange(formState.copy(customerName = it)) },
                    label = { Text("Nama Pemilik Mobil *") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("booking_name_input")
                )

                // No WhatsApp / HP
                OutlinedTextField(
                    value = formState.phoneNumber,
                    onValueChange = { onStateChange(formState.copy(phoneNumber = it)) },
                    label = { Text("Nomor HP / WhatsApp *") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("booking_phone_input")
                )

                // Merk & Tipe Mobil
                OutlinedTextField(
                    value = formState.carBrandModel,
                    onValueChange = { onStateChange(formState.copy(carBrandModel = it)) },
                    label = { Text("Merk & Model Mobil (cth: Avanza / Jazz / Pajero) *") },
                    leadingIcon = { Icon(Icons.Default.CarRepair, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("booking_car_input")
                )

                // Tahun Mobil
                OutlinedTextField(
                    value = formState.carYear,
                    onValueChange = { onStateChange(formState.copy(carYear = it)) },
                    label = { Text("Tahun Mobil (cth: 2019)") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("booking_year_input")
                )

                // Paket Servis Dropdown
                ExposedDropdownMenuBox(
                    expanded = packageExpanded,
                    onExpandedChange = { packageExpanded = !packageExpanded }
                ) {
                    OutlinedTextField(
                        value = formState.servicePackage,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Pilihan Paket Servis") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = packageExpanded) },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = packageExpanded,
                        onDismissRequest = { packageExpanded = false }
                    ) {
                        serviceOptions.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt) },
                                onClick = {
                                    onStateChange(formState.copy(servicePackage = opt))
                                    packageExpanded = false
                                }
                            )
                        }
                    }
                }

                // Tanggal & Jam
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Tanggal Dropdown
                    ExposedDropdownMenuBox(
                        expanded = dateExpanded,
                        onExpandedChange = { dateExpanded = !dateExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = formState.selectedDate,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Hari") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dateExpanded) },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = dateExpanded,
                            onDismissRequest = { dateExpanded = false }
                        ) {
                            dateOptions.forEach { d ->
                                DropdownMenuItem(
                                    text = { Text(d) },
                                    onClick = {
                                        onStateChange(formState.copy(selectedDate = d))
                                        dateExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Jam Dropdown
                    ExposedDropdownMenuBox(
                        expanded = timeExpanded,
                        onExpandedChange = { timeExpanded = !timeExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = formState.selectedTime,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Jam") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = timeExpanded) },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = timeExpanded,
                            onDismissRequest = { timeExpanded = false }
                        ) {
                            timeOptions.forEach { t ->
                                DropdownMenuItem(
                                    text = { Text(t) },
                                    onClick = {
                                        onStateChange(formState.copy(selectedTime = t))
                                        timeExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Catatan Tambahan / Keluhan
                OutlinedTextField(
                    value = formState.customerNotes,
                    onValueChange = { onStateChange(formState.copy(customerNotes = it)) },
                    label = { Text("Catatan / Gejala Kerusakan (Opsional)") },
                    placeholder = { Text("cth: AC kurang dingin saat siang hari") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onSubmit,
                enabled = formState.customerName.isNotBlank() && formState.carBrandModel.isNotBlank(),
                modifier = Modifier.testTag("submit_booking_button")
            ) {
                Text("Konfirmasi Jadwal")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
