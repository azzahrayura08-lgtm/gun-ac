package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.config.WhatsAppConfig
import com.example.data.model.MenuId
import com.example.ui.theme.GunAcAccent
import com.example.ui.theme.GunAcCyanFrost
import com.example.ui.theme.GunAcPrimary
import com.example.ui.theme.GunAcPrimaryDark
import com.example.ui.theme.GunAcSecondary
import com.example.ui.theme.WhatsAppGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GunAcHomeScreen(
    unreadCount: Int,
    onOpenChatbot: () -> Unit,
    onSelectMenuFromHome: (MenuId) -> Unit,
    onOpenBookingDialog: () -> Unit,
    onWhatsAppClick: (String?) -> Unit,
    onOpenMaps: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(GunAcPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AcUnit,
                                contentDescription = "Logo",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "GUN AC MOBIL",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 17.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = GunAcAccent,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "CIREBON",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.Black,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Buka: 08.00 - 17.00 WIB • Pabuaran",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }
                },
                actions = {
                    // Tombol Lokasi Bengkel di TopBar
                    IconButton(
                        onClick = onOpenMaps,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("topbar_maps_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Lokasi Bengkel",
                            tint = GunAcCyanFrost,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = GunAcSecondary
                )
            )
        },
        floatingActionButton = {
            FloatingActionButtonsStack(
                unreadCount = unreadCount,
                onOpenChatbot = onOpenChatbot,
                onWhatsAppClick = { onWhatsAppClick(null) }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(bottom = 110.dp)
        ) {
            // 1. Hero Section with Banner
            item {
                HeroBannerSection(
                    onChatClick = onOpenChatbot,
                    onBookingClick = onOpenBookingDialog,
                    onOpenMaps = onOpenMaps
                )
            }

            // 2. Chatbot Shortcut Menu Grid (5 Menu Resmi)
            item {
                ChatbotMenuShortcutSection(
                    onSelectMenu = onSelectMenuFromHome
                )
            }

            // 3. Featured Services (Layanan Spesialis & Garansi, Tanpa Harga)
            item {
                FeaturedServicesSection(
                    onConsultClick = { onSelectMenuFromHome(MenuId.KONSULTASI_RUSAK) },
                    onBookingClick = onOpenBookingDialog
                )
            }

            // 4. Trouble Symptoms Diagnosis Guide
            item {
                DiagnosisShortcutSection(
                    onConsultClick = { onSelectMenuFromHome(MenuId.KONSULTASI_RUSAK) }
                )
            }

            // 5. Why Choose GUN AC MOBIL (Garansi & Fasilitas Modern)
            item {
                WorkshopBenefitsSection()
            }

            // 6. Section Kontak Resmi & Peta Alamat Lengkap
            item {
                WorkshopContactSection(
                    onWhatsAppClick = { onWhatsAppClick(null) },
                    onOpenMaps = onOpenMaps
                )
            }

            // 7. Footer Resmi
            item {
                WorkshopFooterSection(
                    onWhatsAppClick = { onWhatsAppClick(null) },
                    onOpenMaps = onOpenMaps
                )
            }
        }
    }
}

/**
 * Tombol Mengambang di Pojok Kanan Bawah
 * - Sesuai instruksi: Menggunakan HANYA ikon/logo WhatsApp berwarna hijau di pojok kanan bawah.
 * - Mudah ditekan melalui HP Android (60dp dengan touch target luas).
 * - Saat ditekan: Langsung membuka WhatsApp ke nomor 6281324782858.
 * - Disediakan tombol Chatbot di atasnya agar chatbot tetap mudah diakses.
 */
@Composable
private fun FloatingActionButtonsStack(
    unreadCount: Int,
    onOpenChatbot: () -> Unit,
    onWhatsAppClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "fab_pulse"
    )

    Column(
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.padding(bottom = 8.dp, end = 4.dp)
    ) {
        // Tombol Chatbot (Mengambang di atas ikon WhatsApp)
        FloatingActionButton(
            onClick = onOpenChatbot,
            containerColor = GunAcPrimary,
            contentColor = Color.White,
            shape = CircleShape,
            modifier = Modifier
                .size(48.dp)
                .testTag("floating_chatbot_button")
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Default.AcUnit,
                    contentDescription = "Buka Chatbot",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                if (unreadCount > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(10.dp)
                            .background(Color.Red, CircleShape)
                    )
                }
            }
        }

        // HANYA IKON/LOGO WhatsApp Berwarna Hijau di Pojok Kanan Bawah
        FloatingActionButton(
            onClick = onWhatsAppClick,
            containerColor = WhatsAppGreen,
            contentColor = Color.White,
            shape = CircleShape,
            modifier = Modifier
                .size(60.dp)
                .scale(scale)
                .minimumInteractiveComponentSize()
                .testTag("floating_whatsapp_button")
        ) {
            Icon(
                painter = painterResource(id = R.drawable.ic_whatsapp_logo),
                contentDescription = "WhatsApp",
                tint = Color.White,
                modifier = Modifier.size(34.dp)
            )
        }
    }
}

@Composable
private fun HeroBannerSection(
    onChatClick: () -> Unit,
    onBookingClick: () -> Unit,
    onOpenMaps: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
        colors = CardDefaults.cardColors(containerColor = GunAcSecondary),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Visual Hero Image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.banner_gun_ac_hero_1794195913205),
                    contentDescription = "Bengkel GUN AC MOBIL",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                // Gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, GunAcSecondary.copy(alpha = 0.88f))
                            )
                        )
                )
            }

            // Text and CTAs (Tanpa menampilkan nomor telepon)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = GunAcAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Bengkel Spesialis AC Mobil Terpercaya • Cirebon Timur",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = GunAcAccent
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "AC Mobil Kurang Dingin atau Bau Apek? Segera Atasi di GUN AC MOBIL!",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    lineHeight = 26.sp,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Layanan servis kompresor, flushing sirkulasi otomatis, cuci evaporator endoskopi, dan pengisian freon murni bergaransi resmi.",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.85f),
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Tombol Lokasi Bengkel Utama
                Button(
                    onClick = onOpenMaps,
                    colors = ButtonDefaults.buttonColors(containerColor = GunAcPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("hero_location_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Lokasi Bengkel (Buka Google Maps)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onChatClick,
                        colors = ButtonDefaults.buttonColors(containerColor = GunAcCyanFrost),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("hero_open_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AcUnit,
                            contentDescription = null,
                            tint = Color(0xFF0F172A),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Tanya Chatbot",
                            color = Color(0xFF0F172A),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onBookingClick,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Booking Servis",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatbotMenuShortcutSection(
    onSelectMenu: (MenuId) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Layanan Chatbot Pelanggan",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Surface(
                color = Color(0xFFDCFCE7),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "Respon Otomatis 24 Jam",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF166534),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 5 Menu Resmi: Konsultasi kerusakan, Booking jadwal, Informasi layanan, Lokasi dan jam, Hubungi admin
        val menuList = listOf(
            Triple(MenuId.KONSULTASI_RUSAK, "1. Konsultasi kerusakan AC mobil", "Diagnosa gejala AC tidak dingin/berbau"),
            Triple(MenuId.BOOKING_JADWAL, "2. Booking jadwal servis", "Daftar jadwal servis bebas antre"),
            Triple(MenuId.INFORMASI_LAYANAN, "3. Informasi layanan bengkel", "Garansi 6 bulan & fasilitas komputerisasi"),
            Triple(MenuId.LOKASI_OPERASIONAL, "4. Lokasi dan jam operasional", "Pasar Sayur Pabuaran & Rute Google Maps"),
            Triple(MenuId.HUBUNGI_ADMIN, "5. Hubungi admin", "Buka chat WhatsApp admin")
        )

        menuList.forEach { (id, title, desc) ->
            ElevatedCard(
                onClick = { onSelectMenu(id) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .testTag("home_shortcut_${id.name}")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                when (id) {
                                    MenuId.KONSULTASI_RUSAK -> Color(0xFFFEF3C7)
                                    MenuId.BOOKING_JADWAL -> Color(0xFFDCFCE7)
                                    MenuId.INFORMASI_LAYANAN -> Color(0xFFF3E8FF)
                                    MenuId.LOKASI_OPERASIONAL -> Color(0xFFE0F2FE)
                                    MenuId.HUBUNGI_ADMIN -> Color(0xFFCCFBF1)
                                },
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (id) {
                                MenuId.KONSULTASI_RUSAK -> Icons.Default.Build
                                MenuId.BOOKING_JADWAL -> Icons.Default.CalendarMonth
                                MenuId.INFORMASI_LAYANAN -> Icons.Default.Info
                                MenuId.LOKASI_OPERASIONAL -> Icons.Default.LocationOn
                                MenuId.HUBUNGI_ADMIN -> Icons.AutoMirrored.Filled.Chat
                            },
                            contentDescription = null,
                            tint = when (id) {
                                MenuId.KONSULTASI_RUSAK -> GunAcAccent
                                MenuId.BOOKING_JADWAL -> Color(0xFF16A34A)
                                MenuId.INFORMASI_LAYANAN -> Color(0xFF9333EA)
                                MenuId.LOKASI_OPERASIONAL -> GunAcPrimary
                                MenuId.HUBUNGI_ADMIN -> WhatsAppGreen
                            },
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = desc,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = "Buka →",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GunAcPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun FeaturedServicesSection(
    onConsultClick: () -> Unit,
    onBookingClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "Layanan Spesialis GUN AC MOBIL",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        Text(
            text = "Dikerjakan oleh teknisi ahli menggunakan mesin otomatis & komputerisasi",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ServiceHighlightCard(
                title = "Servis Ringan & Fogging",
                tag = "Sterilisasi Bakteri",
                desc = "Bersihkan filter kabin, blower, dan sterilkan kabin mobil",
                modifier = Modifier.weight(1f),
                onClick = onConsultClick
            )
            ServiceHighlightCard(
                title = "Flushing & Kuras Freon",
                tag = "Mesin Komputerisasi",
                desc = "Vacuum bertekanan tinggi & penggantian oli kompresor murni",
                modifier = Modifier.weight(1f),
                onClick = onConsultClick
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ServiceHighlightCard(
                title = "Cuci Evaporator Endoskopi",
                tag = "Tanpa Bongkar",
                desc = "Pembersihan kamera HD higienis tanpa merusak dashboard",
                modifier = Modifier.weight(1f),
                onClick = onConsultClick
            )
            ServiceHighlightCard(
                title = "Perbaikan Kompresor",
                tag = "Garansi 6 Bulan",
                desc = "Penggantian bearing aus, magnetic clutch & seal bocor",
                modifier = Modifier.weight(1f),
                onClick = onBookingClick
            )
        }
    }
}

@Composable
private fun ServiceHighlightCard(
    title: String,
    tag: String,
    desc: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Surface(
                color = GunAcPrimary.copy(alpha = 0.12f),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = tag,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = GunAcPrimary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 1
            )
            Text(
                text = desc,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 14.sp,
                maxLines = 2,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
private fun DiagnosisShortcutSection(
    onConsultClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F9FF)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBAE6FD))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = null,
                    tint = GunAcPrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Kenali Gejala Kerusakan AC Mobil Anda",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            val symptoms = listOf(
                "• AC Hanya keluar hembusan angin biasa saat siang hari",
                "• Bau apek asam menyengat saat AC pertama dinyalakan",
                "• Suara berdecit / mendengung kasar dari ruang mesin",
                "• Tetesan air membasahi karpet lantai bawah dashboard"
            )

            symptoms.forEach { s ->
                Text(
                    text = s,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = onConsultClick,
                colors = ButtonDefaults.buttonColors(containerColor = GunAcPrimary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Konsultasikan Masalah AC ke Chatbot", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun WorkshopBenefitsSection() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "Keunggulan Bengkel GUN AC MOBIL",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        val benefits = listOf(
            Pair("Garansi Servis Resmi Hingga 6 Bulan", "Jaminan hasil dingin memuaskan dan tenang di perjalanan."),
            Pair("Teknologi Flushing Komputerisasi", "Pembersihan sirkulasi oli dan freon otomatis tanpa sisa kerak."),
            Pair("Pengecekan Sistem AC Cepat & Akurat", "Cek kondisi tekanan freon, kompresor, dan kebocoran pipa."),
            Pair("Ruang Tunggu Ber-AC & Free WiFi", "Pantau mobil dengan nyaman sambil menikmati fasilitas santai.")
        )

        benefits.forEach { (title, sub) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF16A34A),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(sub, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun WorkshopContactSection(
    onWhatsAppClick: () -> Unit,
    onOpenMaps: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = GunAcPrimary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Kontak Resmi & Lokasi Bengkel",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Alamat Lengkap dapat diklik untuk membuka Google Maps
            Surface(
                color = Color(0xFFF1F5F9),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenMaps)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "📍 Alamat Bengkel (Klik untuk buka rute Google Maps):",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = WhatsAppConfig.WORKSHOP_ADDRESS,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textDecoration = TextDecoration.Underline
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Map, contentDescription = null, tint = GunAcPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Buka rute langsung di Google Maps",
                            fontSize = 11.sp,
                            color = GunAcPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Jam Operasional
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Schedule, contentDescription = null, tint = GunAcAccent, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = WhatsAppConfig.WORKSHOP_HOURS,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tombol "Lokasi Bengkel" (Membuka rute Google Maps persis ke GUN AC MOBIL)
            Button(
                onClick = onOpenMaps,
                colors = ButtonDefaults.buttonColors(containerColor = GunAcPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contact_maps_button")
            ) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Lokasi Bengkel", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Tombol Chat WhatsApp (tanpa nomor teks)
            Button(
                onClick = onWhatsAppClick,
                colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contact_whatsapp_button")
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_whatsapp_logo),
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Chat WhatsApp", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun WorkshopFooterSection(
    onWhatsAppClick: () -> Unit,
    onOpenMaps: () -> Unit
) {
    Surface(
        color = GunAcSecondary,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(GunAcPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AcUnit,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "GUN AC MOBIL",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Bengkel Spesialis Perawatan, Perbaikan, dan Solusi AC Mobil Bergaransi.",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.8f),
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(12.dp))

            // Footer Address (Clickable directly opens Google Maps)
            Text(
                text = "ALAMAT BENGKEL:",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = GunAcAccent
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = WhatsAppConfig.WORKSHOP_ADDRESS,
                fontSize = 12.sp,
                color = Color.White,
                lineHeight = 17.sp,
                textDecoration = TextDecoration.Underline,
                modifier = Modifier
                    .clickable(onClick = onOpenMaps)
                    .testTag("footer_address_link")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Footer Lokasi Bengkel Button
            Button(
                onClick = onOpenMaps,
                colors = ButtonDefaults.buttonColors(containerColor = GunAcPrimaryDark),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Lokasi Bengkel (Google Maps)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Footer Jam Operasional
            Text(
                text = "JAM OPERASIONAL:",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = GunAcAccent
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = WhatsAppConfig.WORKSHOP_HOURS,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.85f)
            )

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "© 2026 GUN AC MOBIL • Cirebon Timur. All rights reserved.",
                fontSize = 10.sp,
                color = Color.White.copy(alpha = 0.6f)
            )
        }
    }
}
