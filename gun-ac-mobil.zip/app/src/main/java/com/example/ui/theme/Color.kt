package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand colors for GUN AC MOBIL
val GunAcPrimary = Color(0xFF0284C7) // Sky cool blue
val GunAcPrimaryDark = Color(0xFF0369A1)
val GunAcSecondary = Color(0xFF0F172A) // Deep automotive slate navy
val GunAcSecondaryLight = Color(0xFF1E293B)
val GunAcAccent = Color(0xFFF59E0B) // Amber gold for ratings & highlight
val GunAcCyanFrost = Color(0xFF38BDF8) // Bright ice cyan
val GunAcIceBackground = Color(0xFFF0F9FF) // Fresh icy background

// WhatsApp Brand Color
val WhatsAppGreen = Color(0xFF25D366)
val WhatsAppGreenDark = Color(0xFF128C7E)

// Neutral UI colors
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

val SurfaceDark = Color(0xFF0B132B)
val SurfaceVariantDark = Color(0xFF1C2541)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
