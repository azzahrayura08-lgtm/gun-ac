package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.config.WhatsAppConfig
import com.example.data.model.ChatMessage
import com.example.data.model.ChatPayload
import com.example.data.model.DiagnosisSymptom
import com.example.data.model.MenuId
import com.example.data.model.MenuOption
import com.example.data.model.QuickReply
import com.example.data.model.SenderType
import com.example.ui.theme.GunAcAccent
import com.example.ui.theme.GunAcPrimary
import com.example.ui.theme.GunAcSecondary
import com.example.ui.theme.WhatsAppGreen

@Composable
fun ChatbotOverlay(
    isVisible: Boolean,
    messages: List<ChatMessage>,
    isTyping: Boolean,
    inputMessage: String,
    menuOptions: List<MenuOption>,
    onClose: () -> Unit,
    onInputChanged: (String) -> Unit,
    onSendMessage: (String?) -> Unit,
    onSelectMenu: (MenuId) -> Unit,
    onSelectQuickReply: (QuickReply) -> Unit,
    onRestartChat: () -> Unit,
    onWhatsAppClick: (String?) -> Unit,
    onOpenBookingForm: () -> Unit,
    onOpenMaps: () -> Unit
) {
    val listState = rememberLazyListState()

    // Auto-scroll ke pesan terbaru
    LaunchedEffect(messages.size, isTyping) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    AnimatedVisibility(
        visible = isVisible,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable(onClick = onClose)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.92f)
                    .align(Alignment.BottomCenter)
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .clickable(enabled = false) {}
                    .imePadding()
                    .navigationBarsPadding()
                    .testTag("chatbot_overlay_panel"),
                color = MaterialTheme.colorScheme.background,
                tonalElevation = 8.dp
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Chatbot Header dengan Tombol WhatsApp Resmi
                    ChatbotHeader(
                        onClose = onClose,
                        onRestart = onRestartChat,
                        onWhatsAppClick = { onWhatsAppClick(null) }
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // Aliran Pesan Chat
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp),
                        contentPadding = PaddingValues(vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            ChatMessageRow(
                                message = msg,
                                menuOptions = menuOptions,
                                onSelectMenu = onSelectMenu,
                                onSelectQuickReply = onSelectQuickReply,
                                onWhatsAppClick = onWhatsAppClick,
                                onOpenBookingForm = onOpenBookingForm,
                                onOpenMaps = onOpenMaps
                            )
                        }

                        if (isTyping) {
                            item {
                                BotTypingIndicator()
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                    // Bagian Input Teks Chat
                    ChatInputBar(
                        inputMessage = inputMessage,
                        onInputChanged = onInputChanged,
                        onSendMessage = { onSendMessage(null) },
                        onWhatsAppClick = { onWhatsAppClick(null) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatbotHeader(
    onClose: () -> Unit,
    onRestart: () -> Unit,
    onWhatsAppClick: () -> Unit
) {
    Surface(
        color = GunAcSecondary,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(GunAcPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AcUnit,
                        contentDescription = "GUN AC",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "GUN AC MOBIL",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color(0xFF22C55E), CircleShape)
                        )
                    }
                    Text(
                        text = "Asisten Servis Online • Pabuaran",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Tombol WhatsApp Resmi di Header Chatbot
                Button(
                    onClick = onWhatsAppClick,
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .padding(end = 4.dp)
                        .minimumInteractiveComponentSize()
                        .testTag("header_whatsapp_button")
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_whatsapp_logo),
                        contentDescription = "WhatsApp",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "WA",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                // Tombol Mulai Ulang Chat
                IconButton(
                    onClick = onRestart,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("header_restart_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Mulai Ulang Percakapan",
                        tint = Color.White.copy(alpha = 0.85f)
                    )
                }

                // Tombol Tutup Chat
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("header_close_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Tutup Chat",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatMessageRow(
    message: ChatMessage,
    menuOptions: List<MenuOption>,
    onSelectMenu: (MenuId) -> Unit,
    onSelectQuickReply: (QuickReply) -> Unit,
    onWhatsAppClick: (String?) -> Unit,
    onOpenBookingForm: () -> Unit,
    onOpenMaps: () -> Unit
) {
    val isUser = message.sender == SenderType.USER

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(if (isUser) 0.85f else 0.95f),
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
        ) {
            if (!isUser) {
                Box(
                    modifier = Modifier
                        .padding(top = 4.dp, end = 8.dp)
                        .size(32.dp)
                        .background(GunAcPrimary.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AcUnit,
                        contentDescription = "Bot",
                        tint = GunAcPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Column(horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
                Surface(
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    ),
                    color = if (isUser) GunAcPrimary else MaterialTheme.colorScheme.surfaceVariant,
                    tonalElevation = 2.dp,
                    modifier = Modifier.testTag("chat_bubble_${message.id}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = message.text,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 20.sp
                        )

                        Text(
                            text = message.timestamp,
                            fontSize = 10.sp,
                            color = if (isUser) Color.White.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier
                                .align(Alignment.End)
                                .padding(top = 4.dp)
                        )
                    }
                }

                // Render 5 Menu Utama
                if (message.showMainMenu) {
                    Spacer(modifier = Modifier.height(8.dp))
                    MainMenuCards(menuOptions = menuOptions, onSelect = onSelectMenu)
                }

                // Render Payload Kartu (Diagnosa, Booking, Info Layanan, Lokasi Maps, Admin)
                message.payload?.let { payload ->
                    Spacer(modifier = Modifier.height(8.dp))
                    when (payload) {
                        is ChatPayload.DiagnosisGuide -> DiagnosisCard(
                            payload = payload,
                            onBookingClick = onOpenBookingForm,
                            onWhatsAppClick = { onWhatsAppClick("Konsultasi Kerusakan AC") }
                        )
                        is ChatPayload.BookingSummary -> BookingSummaryCard(
                            payload = payload,
                            onWhatsAppClick = {
                                onWhatsAppClick("Konfirmasi Booking #${payload.bookingCode} untuk mobil ${payload.carInfo}")
                            },
                            onOpenMaps = onOpenMaps
                        )
                        is ChatPayload.ServiceInfo -> ServiceInfoCard(
                            payload = payload,
                            onWhatsAppClick = { onWhatsAppClick("Info Layanan Bengkel") },
                            onBookingClick = onOpenBookingForm
                        )
                        is ChatPayload.LocationAndHours -> LocationAndHoursCard(
                            payload = payload,
                            onOpenMaps = onOpenMaps,
                            onWhatsAppClick = { onWhatsAppClick("Info Lokasi & Rute Bengkel") }
                        )
                        is ChatPayload.AdminContact -> AdminContactCard(
                            payload = payload,
                            onWhatsAppClick = { onWhatsAppClick(null) },
                            onOpenMaps = onOpenMaps
                        )
                    }
                }

                // Tombol WhatsApp Otomatis
                if (message.showWhatsAppButton) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = { onWhatsAppClick(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .padding(vertical = 4.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("chat_whatsapp_action_button")
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_whatsapp_logo),
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Chat WhatsApp Sekarang",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                // Quick Replies Chips
                if (message.quickReplies.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    QuickRepliesRow(
                        replies = message.quickReplies,
                        onSelect = onSelectQuickReply
                    )
                }
            }
        }
    }
}

@Composable
private fun MainMenuCards(
    menuOptions: List<MenuOption>,
    onSelect: (MenuId) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        menuOptions.forEach { option ->
            ElevatedCard(
                onClick = { onSelect(option.id) },
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("menu_option_${option.number}")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                when (option.number) {
                                    1 -> Color(0xFFFEF3C7)
                                    2 -> Color(0xFFDCFCE7)
                                    3 -> Color(0xFFF3E8FF)
                                    4 -> Color(0xFFE0F2FE)
                                    else -> Color(0xFFCCFBF1)
                                },
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (option.id == MenuId.HUBUNGI_ADMIN) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_whatsapp_logo),
                                contentDescription = null,
                                tint = WhatsAppGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        } else {
                            Icon(
                                imageVector = when (option.id) {
                                    MenuId.KONSULTASI_RUSAK -> Icons.Default.Build
                                    MenuId.BOOKING_JADWAL -> Icons.Default.CalendarMonth
                                    MenuId.INFORMASI_LAYANAN -> Icons.Default.Info
                                    MenuId.LOKASI_OPERASIONAL -> Icons.Default.LocationOn
                                    else -> Icons.Default.AcUnit
                                },
                                contentDescription = null,
                                tint = when (option.number) {
                                    1 -> GunAcAccent
                                    2 -> Color(0xFF16A34A)
                                    3 -> Color(0xFF9333EA)
                                    4 -> GunAcPrimary
                                    else -> WhatsAppGreen
                                },
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${option.number}. ${option.title}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = option.subtitle,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }

                    Text(
                        text = "Pilih →",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = GunAcPrimary
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun QuickRepliesRow(
    replies: List<QuickReply>,
    onSelect: (QuickReply) -> Unit
) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        replies.forEach { r ->
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                border = androidx.compose.foundation.BorderStroke(1.dp, GunAcPrimary.copy(alpha = 0.3f)),
                modifier = Modifier
                    .clickable { onSelect(r) }
                    .testTag("quick_reply_${r.label}")
            ) {
                Text(
                    text = r.label,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun DiagnosisCard(
    payload: ChatPayload.DiagnosisGuide,
    onBookingClick: () -> Unit,
    onWhatsAppClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Build, contentDescription = null, tint = GunAcAccent, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Panduan Diagnosa Kerusakan",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            payload.symptoms.forEach { item ->
                DiagnosisItemRow(item)
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onBookingClick,
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Jadwalkan Cek", fontSize = 12.sp)
                }

                Button(
                    onClick = onWhatsAppClick,
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_whatsapp_logo),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Chat WhatsApp", fontSize = 12.sp, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun DiagnosisItemRow(item: DiagnosisSymptom) {
    Column {
        Text(
            text = "⚠️ ${item.title}",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "Kemungkinan Penyebab: ${item.probableCause}",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 15.sp,
            modifier = Modifier.padding(top = 2.dp)
        )
        Text(
            text = "Saran Penanganan: ${item.recommendation}",
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = GunAcPrimary,
            lineHeight = 15.sp,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
private fun BookingSummaryCard(
    payload: ChatPayload.BookingSummary,
    onWhatsAppClick: () -> Unit,
    onOpenMaps: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF86EFAC))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Konfirmasi Booking Servis",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF166534)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                color = Color.White,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(text = "Kode Booking: ${payload.bookingCode}", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = GunAcPrimary)
                    Text(text = "Nama: ${payload.customerName}", fontSize = 12.sp)
                    Text(text = "Mobil: ${payload.carInfo}", fontSize = 12.sp)
                    Text(text = "Layanan: ${payload.servicePackage}", fontSize = 12.sp)
                    Text(text = "Waktu: ${payload.appointmentDate}, ${payload.appointmentTime}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "Lokasi: ${WhatsAppConfig.WORKSHOP_ADDRESS}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onWhatsAppClick,
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                    modifier = Modifier
                        .weight(1.3f)
                        .minimumInteractiveComponentSize(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_whatsapp_logo),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Kirim ke WA", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = onOpenMaps,
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Peta", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ServiceInfoCard(
    payload: ChatPayload.ServiceInfo,
    onWhatsAppClick: () -> Unit,
    onBookingClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = "Standar Pelayanan & Fasilitas Bengkel:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))

            payload.highlights.forEach { h ->
                Row(modifier = Modifier.padding(vertical = 2.dp)) {
                    Text("✓", color = GunAcPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(h, fontSize = 11.sp, lineHeight = 15.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text("⏰ Jam Buka: ${payload.operationalHours}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text("🛡 ${payload.warrantyInfo}", fontSize = 11.sp, color = GunAcPrimary, fontWeight = FontWeight.Medium)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onBookingClick,
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Booking Jadwal", fontSize = 12.sp)
                }

                Button(
                    onClick = onWhatsAppClick,
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_whatsapp_logo),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Chat WhatsApp", fontSize = 12.sp, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun LocationAndHoursCard(
    payload: ChatPayload.LocationAndHours,
    onOpenMaps: () -> Unit,
    onWhatsAppClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F9FF)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBAE6FD))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = GunAcPrimary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Lokasi & Jam Operasional",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                color = Color.White,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "Alamat Bengkel:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = payload.address,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Jam Buka:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = payload.operationalHours,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = payload.notes,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onOpenMaps,
                    colors = ButtonDefaults.buttonColors(containerColor = GunAcPrimary),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Lokasi Bengkel", fontSize = 12.sp, color = Color.White)
                }

                Button(
                    onClick = onWhatsAppClick,
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_whatsapp_logo),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("WhatsApp", fontSize = 12.sp, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun AdminContactCard(
    payload: ChatPayload.AdminContact,
    onWhatsAppClick: () -> Unit,
    onOpenMaps: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = "Kontak Admin Resmi GUN AC MOBIL", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "Chat Langsung via WhatsApp", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = WhatsAppGreen)
            Text(text = payload.note, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "📍 Alamat: ${payload.address}", fontSize = 11.sp)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onWhatsAppClick,
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                    modifier = Modifier
                        .weight(1.3f)
                        .minimumInteractiveComponentSize(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_whatsapp_logo),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Chat WhatsApp", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onOpenMaps,
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Google Maps", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun BotTypingIndicator() {
    val transition = rememberInfiniteTransition(label = "typing")
    val alpha1 by transition.animateFloat(
        initialValue = 0.2f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "dot1"
    )
    val alpha2 by transition.animateFloat(
        initialValue = 0.2f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(600, delayMillis = 200), RepeatMode.Reverse), label = "dot2"
    )
    val alpha3 by transition.animateFloat(
        initialValue = 0.2f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(600, delayMillis = 400), RepeatMode.Reverse), label = "dot3"
    )

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.padding(start = 40.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "GUN AC mengetik", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(6.dp))
            Box(modifier = Modifier.size(6.dp).background(GunAcPrimary.copy(alpha = alpha1), CircleShape))
            Spacer(modifier = Modifier.width(3.dp))
            Box(modifier = Modifier.size(6.dp).background(GunAcPrimary.copy(alpha = alpha2), CircleShape))
            Spacer(modifier = Modifier.width(3.dp))
            Box(modifier = Modifier.size(6.dp).background(GunAcPrimary.copy(alpha = alpha3), CircleShape))
        }
    }
}

@Composable
private fun ChatInputBar(
    inputMessage: String,
    onInputChanged: (String) -> Unit,
    onSendMessage: () -> Unit,
    onWhatsAppClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        // Banner Pintasan WhatsApp Admin
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "💬 Butuh bantuan cepat dari admin?",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Surface(
                color = WhatsAppGreen.copy(alpha = 0.15f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.clickable(onClick = onWhatsAppClick)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_whatsapp_logo),
                        contentDescription = null,
                        tint = WhatsAppGreen,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Chat Sekarang",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = WhatsAppGreen
                    )
                }
            }
        }

        // Field Input Pertanyaan & Tombol Kirim (Mendukung tombol Enter dan tombol Kirim)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputMessage,
                onValueChange = onInputChanged,
                placeholder = {
                    Text(
                        text = "Ketik pertanyaan Anda (cth: ac tidak dingin)...",
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chatbot_text_input"),
                shape = RoundedCornerShape(24.dp),
                maxLines = 3,
                singleLine = false,
                keyboardOptions = KeyboardOptions.Default.copy(
                    imeAction = ImeAction.Send
                ),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputMessage.isNotBlank()) {
                            onSendMessage()
                        }
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    focusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = onSendMessage,
                enabled = inputMessage.isNotBlank(),
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        if (inputMessage.isNotBlank()) GunAcPrimary else MaterialTheme.colorScheme.outlineVariant,
                        CircleShape
                    )
                    .testTag("chatbot_send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Kirim Pesan",
                    tint = if (inputMessage.isNotBlank()) Color.White else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
